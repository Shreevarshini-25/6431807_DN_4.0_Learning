package com.example.di;

public class Engine {
    public void start() {
        System.out.println("Engine started.");
    }
}
