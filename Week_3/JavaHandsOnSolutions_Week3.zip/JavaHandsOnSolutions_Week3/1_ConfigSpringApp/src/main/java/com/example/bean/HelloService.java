package com.example.bean;

public class HelloService {
    public void sayHello() {
        System.out.println("Hello from Spring Bean!");
    }
}
