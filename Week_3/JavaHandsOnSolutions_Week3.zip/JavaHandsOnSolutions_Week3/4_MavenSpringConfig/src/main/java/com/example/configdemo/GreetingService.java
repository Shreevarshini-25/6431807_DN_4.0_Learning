package com.example.configdemo;

public class GreetingService {
    public void greet() {
        System.out.println("Hello from Spring Maven project!");
    }
}
